  
  
  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white"> BloodBank & Donor Management System 2019</p>
        </div>
        <!-- /.container -->
    </footer>